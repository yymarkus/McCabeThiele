function y = yEnriching(x, xd, R)

y = (R/(R+1))*x + xd/(R+1);


end
