function [xtrans, NTU] = PackedDistTransition(xf, xd, xb_1, R, F, D, B, run_number, Saving)

%% Number of Transfer Units
xtrans_oldest = 0.11;
xtrans_old = 0.1;
%xb_1 = xb(xf, xd, F, D);
enr_oldest = NTUenr(xd, xtrans_oldest, R);
str_oldest = NTUstr(xd, xf, xtrans_oldest, xb_1, R, F, D);
enr_old = NTUenr(xd, xtrans_old, R);
str_old = NTUstr(xd, xf, xtrans_old, xb_1, R, F, D);
deltaNTU_old = str_old - enr_old;
deltaNTU_oldest = str_oldest - enr_oldest;
iterations = 0;
data_array = zeros(100, 3);
xtrans_new = xtrans_old;
while abs(deltaNTU_old) > 0.01 
    iterations = iterations + 1;
    xtrans_new = xtrans_old - (xtrans_old - xtrans_oldest)*deltaNTU_old/(deltaNTU_old - deltaNTU_oldest);
    xtrans_oldest = xtrans_old;
    xtrans_old = xtrans_new;
    enr_oldest = enr_old;
    str_oldest = str_old;
    enr_old = NTUenr(xd, xtrans_old, R);
    str_old = NTUstr(xd, xf, xtrans_old, xb_1, R, F, D);
    deltaNTU_oldest = str_oldest - enr_oldest;
    deltaNTU_old = str_old - enr_old;
    data_array(iterations, 1) = iterations;
    data_array(iterations, 2) = str_old;    
    data_array(iterations, 3) = enr_old;

end
figure(run_number*2-1);
plot (data_array(1:iterations,1), data_array(1:iterations,2), '-bs');
hold on
plot (data_array(1:iterations,1), data_array(1:iterations,3), '-rs');
titletext1 = ['Iterations of NTU Reflux Ratio ', num2str(R), ':1'];
titletext2 = ['Feed mol%: ' , num2str(round(xf*100,2)), ', Bottoms mol%: ', num2str(round(xb_1*100,2)), ', Distillate mol%: ', num2str(round(xd*100, 2))];
title({titletext1; titletext2});
legend('Stripping', 'Enriching')
xlabel('Iteration #')
ylabel('Number of Transfer Units')
if Saving == true
    saveas(figure(run_number*2-1), ['NTU Reflux: ', R, ' ', titletext2, '.png']);
    hold off
    close(figure(run_number*2-1));
end

%% McCabe Thiele
x1 = zeros(50,1);
y1 = zeros(50,1);
y2 = zeros(50,1);
x1 = linspace(0, 1, 50);
line_str = zeros(50,1);
line_enr = zeros(50,1);
for i=1:50
    y1(i) = fstar(x1(i));
    line_str(i) = yStripping(x1(i), xf, xd, R, F, D, xb_1, B);
    line_enr(i) = yEnriching(x1(i), xd, R);
end

figure(run_number*2);
x1 = x1';
p1 = plot(x1, y1);
hold on
titletext1 = ['x-y Diagram Reflux Ratio ', num2str(R), ':1'];
titletext2 = ['Feed mol%: ' , num2str(round(xf*100,2)), ', Bottoms mol%: ', num2str(round(xb_1*100,2)), ', Distillate mol%: ', num2str(round(xd*100, 2))];
title({titletext1; titletext2});
p2 = plot(x1, line_str);
set(line([0  1],[0  1]),'Color',[.5 .5 .5]);
p3 = plot(x1, line_enr);
axis([0 1 0 1]);
xlabel('x [Liquid mol% Ethanol]');
ylabel('y [Vapour mol% Ethanol]');
legend([p1 p2 p3],{'Equilibrium','Stripping','Enriching'});


j=1;
xp = zeros(2,1);
yp = zeros(2,1);
xp(1)=xd;
yp(1)=xd;
y=xd;
McCabeIntersect_fun = @(x) [yStripping(x,xf,xd,R,F,D,xb_1, B) - yEnriching(x, xd, R)];
McCabeIntersect = fzero(McCabeIntersect_fun, xf);
while (xp(j)>McCabeIntersect),
%while (xp(j) > xf),
    fstar_fun = @(x) [fstar(x)-yp(j)];
    xp(j+1) = fzero(fstar_fun, xp(j));
    yp(j+1)= yEnriching(xp(j+1),xd,R);
    set(line([xp(j) xp(j+1)],[yp(j) yp(j)]),'Color',[0 0 1]);
    if (xp(j+1)>McCabeIntersect) set(line([xp(j+1) xp(j+1)],[yp(j) yp(j+1)]),'Color',[0 0 1]);
    end
        j=j+1;
end    
if j == 1
    yp(1) = xd;
    j = j+1;
end
yp(j) = yp(j-1);
while (xp(j)>xb_1),
    yp(j+1)= yStripping(xp(j),xf, xd, R, F, D, xb_1, B);
    fstar_fun = @(x) [fstar(x)-yp(j+1)];
    xp(j+1) = fzero(fstar_fun, 0.1);
    set(line([xp(j) xp(j)],[yp(j) yp(j+1)]),'Color',[0 0 1]);
    set(line([xp(j) xp(j+1)],[yp(j+1) yp(j+1)]),'Color',[0 0 1]);
    
    j=j+1;
end    
yp(j+1)= yStripping(xp(j),xf, xd, R, F, D, xb_1, B);
fstar_fun = @(x) [fstar(x)-yp(j+1)];
xp(j+1) = fzero(fstar_fun, 0.1);
set(line([xp(j) xp(j)],[yp(j) yp(j+1)]),'Color',[0 0 1]);
if Saving == true
    saveas(figure(run_number*2), ['McCabe Reflux: ', R, ' ', titletext2, '.png']); 
    close(figure(run_number*2));
end
xtrans = xtrans_new;
NTU = mean([str_old enr_old])*2;

end
